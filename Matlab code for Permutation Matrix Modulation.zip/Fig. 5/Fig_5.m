% This function was developed to help our readers understand the novel
% index modulation system proposed in:
%
% Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho,
% "Permutation Matrix Modulation", IEEE Transactions on Wireless
% Communications.
% 
% The article can be downloaded at: https://ieeexplore.ieee.org/abstract/document/10002396
%
% This code is the 1st version (Last edited: 28.03.2023)
%
% Please cite our paper as mentioned above if this code is used in any way,
% so that the readers will not be accused for plagiarism.
% 
% Enjoy our code :)

clc; clear all;

% Input
N = 3; % no. of transmit antenna
M = 3; % no. of receive antenna
snr = -10:5:30; % SNR in logarithmic
txSNR = 10.^(snr./10); % SNR in numeric
loop = 1e3;
b = floor(log2(factorial(N))); % no. of modulated bits to a permutation matrix (PM)

%% Covariance matrices of PMM
% Creation of Permutation Matrices (PM)
r_PMM = 2^b; % no. of possible PM
perm = perms(1:N);
Ptemp = zeros(N);
for i = 1:length(perm)
    for j = 1:N
        Ptemp(j,perm(i,j),i) = 1;
    end
end

% Defining power allocations correspond to no. of Tx. antennas
if N == 2
    Gamma = diag([0.7;0.3]);
elseif N == 3
    Gamma = diag([0.39;0.33;0.28]);
elseif N == 4
    Gamma = diag([0.34;0.28;0.22;0.16]);
elseif N ==5
    Gamma = diag([0.32;0.26;0.20;0.14;0.08]);
elseif N == 6
    Gamma = diag([0.27;0.23;0.19;0.14;0.1;0.07]);
end
% PM that will be used
for i = 1:r_PMM
    P(:,:,i) = Ptemp(:,:,length(perm)+1-i);
end
% Covariance matrices of PMM
for i = 1:r_PMM
    C_PMM(:,:,i) = P(:,:,i)*Gamma*P(:,:,i)';
end

%% Achievable rate computation for PMM, SM and GSM
for i = 1:length(snr) % simulation for each SNR value
    disp(['SNR = ',num2str(snr(i)),' dB']); 
    for ii = 1:loop
        
        H = randn(M,N)+1i*randn(M,N); % creation of MIMO channels
        % Singular Value Decomposition (SVD) of the MIMO channels
        if N <= M
            [U A V] = svd(H,0);
        else
            [U A V] = svd(H,'econ');
        end


        %%% Computation of achievable rate for PMM (refer to Upper Bound Refinement Algorithm in Algorithm 1 in our paper)

        cov_PMM = C_PMM; % keeping the covariance matrices the same at each loop
        alpha(1:r_PMM) = 1/r_PMM; % uniform distribution for all alphas
        a = 0; % initialization
        for s = 1:r_PMM % computation of individual rate for all covariance matrices
            Rup_sto_PMM(s) = alpha(s)*(log2(1/alpha(s)) + log2(det(eye(M) + txSNR(i)*H*cov_PMM(:,:,s)*H'))); % refer to equation (21) for the rate computation
        end
        R_up_PMM(1) = real(sum(Rup_sto_PMM)); % computation of R_PMM^(1) -> line 1 in Algorithm 1
        for k = 2:r_PMM % computation of R_PMM^(k) -> line 2 - line 9 in Algorithm 1
            a_i = (alpha(k-1)/(alpha(k-1)+alpha(k)));
            a_j = (alpha(k)/(alpha(k-1)+alpha(k)));
            C_temp = a_i*cov_PMM(:,:,k-1) + a_j*cov_PMM(:,:,k);
            a = alpha(k-1) + alpha(k);
            temp_Rup = a*(log2(1/a) + log2(det(eye(M) + txSNR(i)*H*C_temp*H'))); % refer to equation (21) for the rate computation
            R_up_PMM(k) = real(temp_Rup + sum(Rup_sto_PMM(k+1:r_PMM)));
            cov_PMM(:,:,k) = C_temp;
            alpha(k) = a;
        end
        [R_tight_PMM(ii) idx(i,ii)] = min(R_up_PMM); % taking the smallest R_PMM as R_tight

        %%% Computation of optimal achievable rate with CSIT (using interior point method -> refer to Section IV)
        
        %%%% Transformation from optimization in equation (37) to this code
        %%%% is provided separately in a pdf

        if N == M % works only for N = M = 3 & 4
            u = 3;
            x0 = ones(1,N)*10^-u; % initialization (starting point to search the optimal power allocations)
            Aineq = eye(N); % left-hand side of the inequality constraint
            Aineq(N+1:2*(N),:) = -1*eye(N); % left-hand side of the inequality constraint
            bineq = ones(N,1); % right-hand side of the inequality constraint
            bineq(N+1:2*(N)) = zeros(N,1); % right-hand side of the inequality constraint
            Aeq = ones(1,N); % left-hand side of the equality constraint
            beq = 1; % right-hand side of the equality constraint (total power at each transmission)
            a_uni = 1/r_PMM; % uniform distribution for all alphas

            if N==3
                fun = @(x)-(log(det(eye(M) + txSNR(i)*a_uni*A*(P(:,:,1)*diag([x(1);x(2);x(3)])*P(:,:,1)' + P(:,:,2)*diag([x(1);x(2);x(3)])*P(:,:,2)' ...
                    + P(:,:,3)*diag([x(1);x(2);x(3)])*P(:,:,3)' + P(:,:,4)*diag([x(1);x(2);x(3)])*P(:,:,4)')*A))); % objective function for N = 3 (all pdfs are merged)

                xopt = fmincon(fun,x0,Aineq,bineq,Aeq,beq);
            elseif N==4
                if idx(i,ii) == r_PMM % to detect if all pdfs are merged
                    % objective function for N = 4 (if all pdfs are merged)
                    fun = @(x)-(log(det(eye(M) + txSNR(i)*a_uni*A*(P(:,:,1)*diag([x(1);x(2);x(3);x(4)])*P(:,:,1)' + P(:,:,2)*diag([x(1);x(2);x(3);x(4)])*P(:,:,2)' ...
                    + P(:,:,3)*diag([x(1);x(2);x(3);x(4)])*P(:,:,3)' + P(:,:,4)*diag([x(1);x(2);x(3);x(4)])*P(:,:,4)' + P(:,:,5)*diag([x(1);x(2);x(3);x(4)])*P(:,:,5)' ...
                    + P(:,:,6)*diag([x(1);x(2);x(3);x(4)])*P(:,:,6)' + P(:,:,7)*diag([x(1);x(2);x(3);x(4)])*P(:,:,7)' + P(:,:,8)*diag([x(1);x(2);x(3);x(4)])*P(:,:,8)' ...
                    + P(:,:,9)*diag([x(1);x(2);x(3);x(4)])*P(:,:,9)' + P(:,:,10)*diag([x(1);x(2);x(3);x(4)])*P(:,:,10)' + P(:,:,11)*diag([x(1);x(2);x(3);x(4)])*P(:,:,11)' ...
                    + P(:,:,12)*diag([x(1);x(2);x(3);x(4)])*P(:,:,12)' + P(:,:,13)*diag([x(1);x(2);x(3);x(4)])*P(:,:,13)' + P(:,:,14)*diag([x(1);x(2);x(3);x(4)])*P(:,:,14)' ...
                    + P(:,:,15)*diag([x(1);x(2);x(3);x(4)])*P(:,:,15)' + P(:,:,16)*diag([x(1);x(2);x(3);x(4)])*P(:,:,16)')*A)));
                    
                    xopt = fmincon(fun,x0,Aineq,bineq,Aeq,beq);
                elseif idx(i,ii) == r_PMM-1 % to detect if pdfs f_y^(1)-f_y^(15) are merged and f_y^(16) is not
                    a_tight = a_uni*(r_PMM-1);
                    % objective function for N = 4 (if the pdfs f_y^(1)-f_y^(15) are merged and f_y^(16) is not)
                    fun = @(x)-(a_tight*(log(1/a_tight) + log(det(eye(M) + txSNR(i)*a_uni*A*(P(:,:,1)*diag([x(1);x(2);x(3);x(4)])*P(:,:,1)' + P(:,:,2)*diag([x(1);x(2);x(3);x(4)])*P(:,:,2)' ...
                    + P(:,:,3)*diag([x(1);x(2);x(3);x(4)])*P(:,:,3)' + P(:,:,4)*diag([x(1);x(2);x(3);x(4)])*P(:,:,4)' + P(:,:,5)*diag([x(1);x(2);x(3);x(4)])*P(:,:,5)' ...
                    + P(:,:,6)*diag([x(1);x(2);x(3);x(4)])*P(:,:,6)' + P(:,:,7)*diag([x(1);x(2);x(3);x(4)])*P(:,:,7)' + P(:,:,8)*diag([x(1);x(2);x(3);x(4)])*P(:,:,8)' ...
                    + P(:,:,9)*diag([x(1);x(2);x(3);x(4)])*P(:,:,9)' + P(:,:,10)*diag([x(1);x(2);x(3);x(4)])*P(:,:,10)' + P(:,:,11)*diag([x(1);x(2);x(3);x(4)])*P(:,:,11)' ...
                    + P(:,:,12)*diag([x(1);x(2);x(3);x(4)])*P(:,:,12)' + P(:,:,13)*diag([x(1);x(2);x(3);x(4)])*P(:,:,13)' + P(:,:,14)*diag([x(1);x(2);x(3);x(4)])*P(:,:,14)' ...
                    + P(:,:,15)*diag([x(1);x(2);x(3);x(4)])*P(:,:,15)')*A))) + a_uni*(log(1/a_uni) + log(det(eye(M) ... % merged pdfs
                    + txSNR(i)*a_uni*A*(P(:,:,16)*diag([x(1);x(2);x(3);x(4)])*P(:,:,16)')*A)))); % unmerged cov. matrix

                    xopt = fmincon(fun,x0,Aineq,bineq,Aeq,beq);
                end
            end

            Gamma_opt = diag(xopt); % the optimal power allocations

            %%% Re-calculate the achievable rate using "Gamma_opt"
            C_opt_PMM = zeros(N,N,r_PMM);
            for aa = 1:r_PMM
                C_opt_PMM(:,:,aa) = P(:,:,aa)*Gamma_opt*P(:,:,aa)';
            end
            cov_opt_PMM = C_opt_PMM;
            alpha_opt_PMM = ones(1,r_PMM)*1/r_PMM;
            a = 0;
            for s = 1:r_PMM
                Rup_sto_opt_PMM(s) = alpha_opt_PMM(s)*(log2(1/alpha_opt_PMM(s)) + log2(det(eye(M) + txSNR(i)*A*cov_opt_PMM(:,:,s)*A')));
            end
            R_up_opt_PMM(1) = real(sum(Rup_sto_opt_PMM));
            for k = 2:r_PMM
                a_i = (alpha_opt_PMM(k-1)/(alpha_opt_PMM(k-1)+alpha_opt_PMM(k)));
                a_j = (alpha_opt_PMM(k)/(alpha_opt_PMM(k-1)+alpha_opt_PMM(k)));
                C_temp = a_i*cov_opt_PMM(:,:,k-1) + a_j*cov_opt_PMM(:,:,k);
                a = alpha_opt_PMM(k-1) + alpha_opt_PMM(k);
                temp_Rup = a*(log2(1/a) + log2(det(eye(M) + txSNR(i)*A*C_temp*A')));
                R_up_opt_PMM(k) = real(temp_Rup + sum(Rup_sto_opt_PMM(k+1:r_PMM)));
                cov_opt_PMM(:,:,k) = C_temp;
                alpha_opt_PMM(k) = a;
            end
            Rup_min_opt_PMM(ii) = R_up_opt_PMM(idx(i,ii));
        else
            Rup_min_opt_PMM(ii) = 0;
        end

        %%% Computation of achievable rate for MIMO waterfilling
        WF_tolerance = 1e-8; % water level tolerance
        N0 = 1;
        v_lower = 0;
        v_upper = 10000;
        Pstar = zeros(N,1);
        while (WF_tolerance <= abs(sum(Pstar)-txSNR(i))) 
            % Set actual water level (bisection)
            v = (v_lower + v_upper)/2;
            % Calculate optimal power terms for different time instances
            Pstar = max(0,(v-N0./sum(A,2)));

            % See if power constraint is violated and adjust upper or lower
            % limit of water level accordingly
            if sum(Pstar) > txSNR(i)
                v_upper = v;
            elseif sum(Pstar) <= txSNR(i)
                v_lower = v;
            end
        end     
        R_mimo_wf(ii) = log2(det(eye(N)+A*diag(Pstar)*A));
    end
    
    R_tight_mean_PMM(i) = mean(R_tight_PMM);
    Rup_mean_opt_PMM(i) = mean(Rup_min_opt_PMM);
    R_mean_mimo_wf(i) = mean(R_mimo_wf);
end

figure(1),
plot(snr,R_tight_mean_PMM,'-','LineWidth',2), grid on, hold on
plot(snr,Rup_mean_opt_PMM,'--','LineWidth',2)
plot(snr,R_mean_mimo_wf,'-*','LineWidth',2)

xlabel('SNR (dB)') 
ylabel('Achievable rate (bits/Hz)') 
legend(strcat(num2str(N),'\times',num2str(M),' PMM CSIR'),strcat(num2str(N),'\times',num2str(M),' PMM optimal'),strcat(num2str(N),'\times',num2str(M),' MIMO waterfilling'),'Location','northwest')


