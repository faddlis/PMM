% This function was developed to help our readers understand the novel
% index modulation system proposed in:
%
% Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho,
% "Permutation Matrix Modulation", IEEE Transactions on Wireless
% Communications, To appear.
% 
% The article can be downloaded at: https://arxiv.org/abs/2112.13630v3
% (to be published in IEEE Transactions on Wireless
% Communications)
%
% This code is the 1st version (Last edited: 28.12.2022)
%
% Please cite our paper as mentioned above if this code is used in any way,
% so that the readers will not be accused for plagiarism.
% 
% Enjoy our code :)

clc; clear all;
N = 2:1:16; % no. of transmit antenna
Q = 4; % modulation level
T = 3; % no. of used timeslot for full transmission

% for PMM
A_PMM = floor(log2(factorial(floor(N)))) + N*log2(Q);

% for SM
A_SM = floor(log2(N)) + log2(Q);

% for QSM
A_QSM = floor(log2(N.^2)) + log2(Q);

% for GSM
for j = 1:length(N)
    max_Nact = 0;
    for i = 1:N(j)
        max_Nact(i) = nchoosek(floor(N(j)),i);
    end
    [~,N_act(j)] = max(max_Nact);
    A_GSM(j) = floor(log2(nchoosek(floor(N(j)),N_act(j)))) + N(j)*log2(Q);
end

% for STSK
A_stsk = floor(log2(N*Q))/T;

% for GSTSK
for p = 1:length(N)
    max_P = 0;
    for i = 1:N(p)
        max_P(i) = nchoosek(N(p),i);
    end
    [~,P_act] = max(max_P);
    A_gstsk(p) = (floor(log2(nchoosek(N(p),P_act)) + P_act*log2(Q)))/T;
end

% for DSM
A_dsm = floor(log2(factorial(floor(N)))) + log2(Q);

plot(N,A_PMM,'o','LineWidth',2),grid on, hold on
plot(N,A_SM,'x','LineWidth',2)
plot(N,A_GSM,'v','LineWidth',2)
plot(N,A_QSM,'*','LineWidth',2)
plot(N,A_stsk,'square','LineWidth',2)
plot(N,A_gstsk,'pentagram','LineWidth',2)
plot(N,A_dsm,'^','LineWidth',2)
legend('PMM (proposed)','SM','GSM','QSM','STSK','GSTSK','DSM','Location','northwest')
