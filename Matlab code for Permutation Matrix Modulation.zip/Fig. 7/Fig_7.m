% This function was developed to help our readers understand the novel
% index modulation system proposed in:
%
% Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho,
% "Permutation Matrix Modulation", IEEE Transactions on Wireless
% Communications, To appear.
% 
% The article can be downloaded at: https://arxiv.org/abs/2112.13630v3
% (to be published in IEEE Transactions on Wireless
% Communications)
%
% This code is the 1st version (Last edited: 28.12.2022)
%
% Please cite our paper as mentioned above if this code is used in any way,
% so that the readers will not be accused for plagiarism.
% 
% Enjoy our code :)

clc; clear all;

%% Input parameter
N = 4; % no. of transmit antenna -> fixed
M = 4; % no. of receive antenna
Q = 4; % modulation level
k = 5; % for total no. of generated bits -> for short simulation, make k = 2
snr = 0:5:40;
loop = 3; % no. of iteration -> for short simulation, make loop = 1
b_pmm = floor(log2(factorial(N))); % no. of modulated bits to a permutation matrix (PM)
r_pmm = 2^b_pmm; % no. of covariance matrices
all_symb = pskmod((0:Q-1),Q); % generate all PSK symbols
Eac = (mean(all_symb .* conj(all_symb)));
N0 = (Eac)*10.^(-snr/10); % noise variance
marray = log2(Q); % no. of bit per symbol
bits_cons = marray*10^k; % total no. of generated bits for cons. symbols
bits_PM = b_pmm*10^k; % total no. of generated bits for PMs
rho = 1; % normalized tx. power

PA_mode = 2; % define PA mode here (either 1 or 2)

%% Signal Mapping
for ante=1:N % loop for symbol positioning (similar to MIMO)
    bit_sym(ante,:) = randi([0 1],1,bits_cons);
    bit_block_sym = reshape(bit_sym(ante,:),marray,bits_cons/marray);
    decimal_symb(ante,:) = bi2de(bit_block_sym(1:marray,:).','left-msb')'; % decimal for constellation
    x_pmm(ante,:) = pskmod(decimal_symb(ante,:),Q);
end

bit_str_PM = randi([0 1],1,bits_PM); % generation of bits for PM modulation
bit_block_PM = reshape(bit_str_PM,b_pmm,bits_PM/b_pmm);
decimal_PM = bi2de(bit_block_PM(1:b_pmm,:).','left-msb')'; % decimal for PM

% Creation of Permutation Matrices (PM)
perm = perms(1:N);
P = zeros(N);
for a = 1:length(perm)
    for b = 1:N
        P(b,perm(a,b),a) = 1;
    end
end

% Generation of all possible symbols (for ML)
for i = 1:N
    pl = (Q^N/(Q^i));
    for ii = 1:Q
        for iii = (ii-1)*pl+1:ii*pl
            s(i,iii) = ii;
        end
    end
    while s(i,Q^N) == 0
        s(i,:) = repmat(s(i,1:Q*pl),1,Q^N/(Q*pl));
    end
end

idx_s = s-1;
vec_s = pskmod(idx_s,Q);

if PA_mode == 1
    D = diag([0.34;0.28;0.22;0.16]);
elseif PA_mode == 2
    D = diag([0.45;0.30;0.15;0.10]);
end


%% SER calculation
for i = 1:length(snr)
    disp(['PMM PA-',num2str(PA_mode),' P = ',num2str(snr(i)),' dB'])
    for iter = 1:loop
        for ii=1:length(x_pmm)
            H = 1/sqrt(2)*randn(M,N)+1i*randn(M,N); % generation of MIMO channels
            noise = 1/sqrt(2)*[randn(M,1) + 1i*randn(M,1)]; % generation AWGN noise
            n = noise*(sqrt(N0(i))); % normalized noise times normalized tx. power

            x = rho*P(:,:,decimal_PM(ii)+1)*D*x_pmm(:,ii); % transmit signal
            
            y = H*x + n; % receive signal
            
            % Generate pseudoinverse matrix for ZF
            H_ZF = inv(H'*H)*H';
            yy_ZF = H_ZF*y;

            %% Detection using ZF -> consists of two processes, see Algorithm 2
            % Permutation matrix detection
            for sigma = 1:2^b_pmm
                dec_perm(sigma) = norm(rho*D*inv(P(:,:,sigma))*yy_ZF)^2;
            end            
            [~,detected_sig] = max(dec_perm);
            decoded_decimal_sig(ii) = detected_sig-1;
            dec_block_sig(:,ii) = de2bi(decoded_decimal_sig(ii),b_pmm,'left-msb')';
            
            % Symbol detection
            dec_sym = inv(P(:,:,detected_sig))*yy_ZF;
            dec_decimal_sym(:,ii) = pskdemod(dec_sym,Q);
            
            %% Detection using ML -> joint detection
            for idx_PM = 1:r_pmm
                for idx_sym = 1:Q^N
                    g(idx_PM,idx_sym) = norm(y - H*rho*P(:,:,idx_PM)*D*vec_s(:,idx_sym))^2;
                end
            end
            [val_temp,idx_temp] = min(g);
            [~,idx_sym_ML] = min(val_temp);
            idx_PM_ML(:,ii) = idx_temp(idx_sym_ML)-1;            
            sym_ML(:,ii) = idx_s(:,idx_sym_ML);
        end
        
        % Calculate no. of symbol error for ZF (from all MIMO channels)
        symb_error = symerr(decimal_symb,dec_decimal_sym);
        PM_error = symerr(decimal_PM,decoded_decimal_sig);
        SER_ZF0(iter) = symb_error + PM_error;
        
        % Calculate no. of symbol error for ML (from all MIMO channels)
        symb_error_ML = symerr(decimal_symb,sym_ML);
        PM_error_ML = symerr(decimal_PM,idx_PM_ML);
        SER_ML0(iter) = symb_error_ML + PM_error_ML;
    end
    
    % Calculate the average of symbol error ZF (over all MIMO channels)
    mean_SER_ZF = mean(SER_ZF0);
    if mean_SER_ZF < 1 % used to prevent symbol error < 1 (typically happens when simulate substantial no. of bits)
        mean_SER_ZF = 0;
    end
    tot_SER_ZF(i) = mean_SER_ZF; % the average symbol error at snr(i) for ZF
    
    % Calculate the average of symbol error ML (over all MIMO channels)
    mean_SER_ML = mean(SER_ML0);
    if mean_SER_ML < 1 % used to prevent symbol error < 1 (typically happens when simulate substantial no. of bits)
        mean_SER_ML = 0;
    end
    tot_SER_ML(i) = mean_SER_ML; % the average symbol error at snr(i) for ML
end

SER_ZF = tot_SER_ZF./(prod(size(decimal_symb)) + prod(size(decimal_PM))); % compute SER for ZF
SER_ML = tot_SER_ML./(prod(size(decimal_symb)) + prod(size(decimal_PM))); % compute SER for ML

figure(1),
semilogy(snr,SER_ZF,'-','LineWidth',2,'DisplayName',strcat('ZF PA-',num2str(PA_mode))),grid on,hold on
semilogy(snr,SER_ML,'--','LineWidth',2,'DisplayName',strcat('ML PA-',num2str(PA_mode)))

xlabel('SNR (dB)')
ylabel('SER')
legend('show','Location','northeast')

