% This function was developed to help our readers understand the novel
% index modulation system proposed in:
%
% Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho,
% "Permutation Matrix Modulation", IEEE Transactions on Wireless
% Communications.
% 
% The article can be downloaded at: https://ieeexplore.ieee.org/abstract/document/10002396
%
% This code is the 1st version (Last edited: 28.03.2023)
%
% Please cite our paper as mentioned above if this code is used in any way,
% so that the readers will not be accused for plagiarism.
% 
% Enjoy our code :)

clc; clear all;

% Input
M = 4; % no. of receive antenna for all systems
snr = -10:5:40; % SNR in logarithmic
txSNR = sqrt(10.^(snr/10)); % SNR in numeric

% Modulation level
Q_pmm = 4; % Modulation level for PMM
Q_mimo = 4; % Modulation level for MIMO
Q_sm = 64; % Modulation level for SM
Q_gsm = 8; % Modulation level for GSM

% Antenna number
N_pmm = 3; % no. of tx. antennas for PMM
N_mimo = 4; % no. of tx. antennas for MIMO
N_sm = 4; % no. of tx. antennas for SM 
N_gsm = 4; % no. of tx. antennas for GSM

%% All symbols PMM (generate all possible symbols of PMM)
tot_bit_pmm = floor(log2(factorial(N_pmm))) + N_pmm*log2(Q_pmm); % number of modulated bits
tot_syms_pmm = 2^tot_bit_pmm; % total no. of all symbols
b_pmm = floor(log2(factorial(N_pmm))); % no. of modulated bits to a permutation matrix (PM)
r_PMM = 2^b_pmm; % no. of covariance matrices

% Generation of the cov. matrices
perm = perms(1:N_pmm);
P = zeros(N_pmm);
for a = 1:length(perm)
    for b = 1:N_pmm
        P(b,perm(a,b),a) = 1;
    end
end

% Generation of all possible symbols for PMM
for i = 1:N_pmm
    pl = (Q_pmm^N_pmm/(Q_pmm^i));
    for ii = 1:Q_pmm
        for iii = (ii-1)*pl+1:ii*pl
            s(i,iii) = ii;
        end
    end
    while s(i,Q_pmm^N_pmm) == 0
        s(i,:) = repmat(s(i,1:Q_pmm*pl),1,Q_pmm^N_pmm/(Q_pmm*pl));
    end
end
idx_s = s-1;
vec_s = pskmod(idx_s,Q_pmm);

% Power allocation
if N_pmm == 2
    D = diag([0.75;0.25]);
elseif N_pmm == 3
    D = diag([0.65;0.25;0.1]);
elseif N_pmm == 4
    D = diag([0.34;0.28;0.22;0.16]);
elseif N_pmm ==5
    D = diag([0.32;0.26;0.20;0.14;0.08]);
elseif N_pmm == 6
    D = diag([0.27;0.23;0.19;0.14;0.1;0.07]);
end
DD = sqrt(D);
m = 1;
for i = 1:r_PMM
    for k = 1:length(vec_s)
        all_syms_pmm(:,m) = P(:,:,i)*DD*vec_s(:,k);
        m = m+1;
    end
end

% Pre-compute the denominator of equation (30) -> (x_v-x_w)(x_v-x_w)^H
for i = 1:tot_syms_pmm
    for j = 1:tot_syms_pmm
        delta_pmm(:,:,i,j) = (all_syms_pmm(:,i)-all_syms_pmm(:,j))*(all_syms_pmm(:,i)-all_syms_pmm(:,j))';
    end
end

%% All symbols MIMO (multiplexing MIMO)
all_cons_mimo = pskmod((0:Q_mimo-1),Q_mimo); %PSK
% all_cons_mimo = qammod((0:M_mimo-1),M_mimo,'UnitAveragePower',true); %QAM
tot_bit_mimo = N_mimo*log2(Q_mimo); % number of modulated bits
tot_syms_mimo = 2^tot_bit_mimo; % total no. of all symbols

% Generation of all possible symbols for MIMO
for i = 1:N_mimo
    pl = (Q_mimo^N_mimo/(Q_mimo^i));
    for ii = 1:Q_mimo
        for iii = (ii-1)*pl+1:ii*pl
            s_mimo(i,iii) = ii;
        end
    end
    while s_mimo(i,Q_mimo^N_mimo) == 0
        s_mimo(i,:) = repmat(s_mimo(i,1:Q_mimo*pl),1,Q_mimo^N_mimo/(Q_mimo*pl));
    end
end
idx_s_mimo = s_mimo-1;
vec_s_mimo = pskmod(idx_s_mimo,Q_mimo);
all_syms_mimo = (1/sqrt(N_mimo))*vec_s_mimo;

% Pre-compute the denominator of equation (30) -> (x_v-x_w)(x_v-x_w)^H
for i = 1:tot_syms_mimo
    for j = 1:tot_syms_mimo
        delta_mimo(:,:,i,j) = (all_syms_mimo(:,i)-all_syms_mimo(:,j))*(all_syms_mimo(:,i)-all_syms_mimo(:,j))';
    end
end

%% All symbols SM
all_cons_sm = pskmod((0:Q_sm-1),Q_sm); % PSK modulation
tot_bit_sm = floor(log2(N_sm)) + log2(Q_sm); % number of modulated bits
tot_syms_sm = 2^tot_bit_sm; % total no. of all symbols
b_sm = floor(log2(N_sm)); % no. of modulated bits to an antenna combination
r_SM = 2^b_sm; % no. of covariance matrices

% Generation of all possible symbols for SM
for i = 1:r_SM
    K = zeros(N_sm,N_sm);
    K(i,i) = 1;
    C_SM(:,:,i) = K;
end
m = 1;
for i = 1:r_SM
    for k = 1:Q_sm
        all_syms_sm(:,m) = C_SM(:,:,i)*ones(N_sm,1)*all_cons_sm(k);
        m = m+1;
    end
end

% Pre-compute the denominator of equation (30) -> (x_v-x_w)(x_v-x_w)^H
for i = 1:tot_syms_sm
    for j = 1:tot_syms_sm
        delta_sm(:,:,i,j) = (all_syms_sm(:,i)-all_syms_sm(:,j))*(all_syms_sm(:,i)-all_syms_sm(:,j))';
    end
end

%% All symbols GSM
for i = 1:N_gsm
    max_Nact(i) = nchoosek(N_gsm,i);
end
[~,N_act] = max(max_Nact); % define number of active antennas
b_GSM = floor(log2(nchoosek(N_gsm,N_act))); % no. of modulated bits to an antenna combination
r_GSM = 2^b_GSM; % no. of covariance matrices
post = nchoosek(1:N_gsm,N_act); % the active antenna indices
tot_bit_gsm = floor(log2(nchoosek(N_gsm,N_act))) + N_act*log2(Q_gsm); % number of modulated bits
tot_syms_gsm = 2^tot_bit_gsm; % total no. of all symbols

% Generation of all possible symbols for GSM
for i = 1:N_act
    pl = (Q_gsm^N_act/(Q_gsm^i));
    for ii = 1:Q_gsm
        for iii = (ii-1)*pl+1:ii*pl
            s_gsm(i,iii) = ii;
        end
    end
    while s_gsm(i,Q_gsm^N_act) == 0
        s_gsm(i,:) = repmat(s_gsm(i,1:Q_gsm*pl),1,Q_gsm^N_act/(Q_gsm*pl));
    end
end
idx_s_gsm = s_gsm-1;
vec_s_gsm = pskmod(idx_s_gsm,Q_gsm);
m = 1;
for i = 1:r_GSM    
    for ii = 1:Q_gsm^N_act
        K_GSM = zeros(N_gsm,1);
        for iii = 1:N_act
            K_GSM(post(i,iii),1) = (1/sqrt(N_act))*vec_s_gsm(iii,ii);
        end
        all_syms_gsm(:,m) = K_GSM;
        m = m+1;
    end
end

% Pre-compute the denominator of equation (30) -> (x_v-x_w)(x_v-x_w)^H
for i = 1:tot_syms_gsm
    for j = 1:tot_syms_gsm
        delta_gsm(:,:,i,j) = (all_syms_gsm(:,i)-all_syms_gsm(:,j))*(all_syms_gsm(:,i)-all_syms_gsm(:,j))';
    end
end

%%%%
% tot_syms_pmm
% tot_syms_mimo
% tot_syms_sm
% tot_syms_gsm

for i = 1:length(snr)
    disp(['FCI P = ',num2str(snr(i)),' dB']);
    %% R^FCI PMM (computed using equation (30))
    for m = 1:tot_syms_pmm
        for n = 1:tot_syms_pmm
            exp_D_pmm(m,n) = 1/(det(eye(N_pmm) + txSNR(i)*delta_pmm(:,:,m,n)/4)^M);
        end
    end
    R0_pmm(i) = real(-log2((1/tot_syms_pmm^2)*sum(sum(exp_D_pmm))));

    
    %% R^FCI MIMO (computed using equation (30))
    for m = 1:tot_syms_mimo
        for n = 1:tot_syms_mimo
            exp_D_mimo(m,n) = 1/(det(eye(N_mimo) + txSNR(i)*delta_mimo(:,:,m,n)/4)^M);
        end
    end
    R0_mimo(i) = real(-log2((1/tot_syms_mimo^2)*sum(sum(exp_D_mimo))));

    %% R^FCI SM (computed using equation (30))
    for m = 1:tot_syms_sm
        for n = 1:tot_syms_sm
            exp_D_sm(m,n) = 1/(det(eye(N_sm) + txSNR(i)*delta_sm(:,:,m,n)/4)^M);
        end
    end
    R0_sm(i) = real(-log2((1/tot_syms_sm^2)*sum(sum(exp_D_sm))));

    %% R^FCI GSM (computed using equation (30))
    for m = 1:tot_syms_gsm
        for n = 1:tot_syms_gsm
            exp_D_gsm(m,n) = 1/(det(eye(N_gsm) + txSNR(i)*delta_gsm(:,:,m,n)/4)^M);
        end
    end
    R0_gsm(i) = real(-log2((1/tot_syms_gsm^2)*sum(sum(exp_D_gsm))));
end

figure(1),
plot(snr,R0_pmm,'-','LineWidth',2,'DisplayName',strcat('PMM(',num2str(N_pmm),',',num2str(Q_pmm),',',num2str(M),')')),grid on,hold on
plot(snr,R0_mimo,'--','LineWidth',2,'DisplayName',strcat('MIMO(',num2str(N_mimo),',',num2str(Q_mimo),',',num2str(M),')'))
plot(snr,R0_sm,'-.','LineWidth',2,'DisplayName',strcat('SM(',num2str(N_sm),',',num2str(Q_sm),',',num2str(M),')'))
plot(snr,R0_gsm,':','LineWidth',2,'DisplayName',strcat('GSM(',num2str(N_gsm),',',num2str(Q_gsm),',',num2str(M),')'))

xlabel('SNR (dB)') 
ylabel('Rate (bits/Hz)') 
legend('show','Location','northwest')


