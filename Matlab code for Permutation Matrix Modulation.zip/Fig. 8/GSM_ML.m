% This function was developed to help our readers understand the novel
% index modulation system proposed in:
%
% Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho,
% "Permutation Matrix Modulation", IEEE Transactions on Wireless
% Communications, To appear.
% 
% The article can be downloaded at: https://arxiv.org/abs/2112.13630v3
% (to be published in IEEE Transactions on Wireless
% Communications)
%
% This code is the 1st version (Last edited: 28.12.2022)
%
% Please cite our paper as mentioned above if this code is used in any way,
% so that the readers will not be accused for plagiarism.
% 
% Enjoy our code :)

function[SER_GSM_ML] = GSM_ML(k_main,loop_main,snr_main,N_gsm,Q_gsm,M_gsm)

%% Input parameters
k = k_main; % for total no. of generated bits
loop = loop_main; % no. of iteration
snr = snr_main; % SNR values
N = N_gsm; % number of transmit antennas
Q = Q_gsm; % modulation level
M = M_gsm; % number of receive antenna

all_sym = qammod((0:Q-1),Q);
Eac = (mean(all_sym .* conj(all_sym)));
N0 = (Eac)*10.^(-snr/10); % noise variance
marray = log2(Q); % no. of bit per constellation symbol
for i = 1:N
    max_Nact(i) = nchoosek(N,i);
end
[~,N_act] = max(max_Nact); % define number of active antennas
b_GSM = floor(log2(nchoosek(N,N_act))); % no. of modulated bits to a cov. matrix
tot_bits = b_GSM+N_act*marray; % total no. of bits per transmission
num_of_bits = tot_bits*10^k; % total no. of generated bits

%% Signal mapping
all_ant = 1:1:N;
comb = nchoosek(all_ant,N_act); % defining the active antenna combinations
tx_bits = randi([0 1],1,num_of_bits); % generation of bits
tx_bits2 = reshape(tx_bits,tot_bits,[]); % converting generated bits to blocks
ant_idx = bi2de([tx_bits2(1:b_GSM,:)].' , 'left-msb') + 1; % converting block of bits to decimal number (for antenna combination)
for i = 1:N_act
    decimal_symb(i,:) = bi2de(tx_bits2(b_GSM+marray*i-(marray-1):b_GSM+marray*i,:).','left-msb'); % converting block of bits to decimal number (for constellation symbol)
    tx_symb(i,:) = qammod(decimal_symb(i,:),Q); % symbol modulation
end
for i = 1:length(tx_symb)
    for ii = 1:N_act
        tx_sig(comb(ant_idx(i),ii),i) = (1/N_act)*tx_symb(ii,i); % symbol positioning -> transmit signal
    end
end

% Generation of all possible symbols for ML detection
for i = 1:N_act
    pl = (Q^N_act/(Q^i));
    for ii = 1:Q
        for iii = (ii-1)*pl+1:ii*pl
            s(i,iii) = ii;
        end
    end
    while s(i,Q^N_act) == 0
        s(i,:) = repmat(s(i,1:Q*pl),1,Q^N_act/(Q*pl));
    end
end
idx_s = s-1;
vec_s = qammod(idx_s,Q);
for a = 1:size(s,2)
    for b = 1:2^b_GSM
        for c = 1:N_act
            ML_sym(comb(b,c),b,a) = (1/N_act)*vec_s(c,a);
        end
    end
end

%% SER calculation
for a = 1:length(snr)
    disp(['GSM P = ',num2str(snr(a)),' dB'])
    for iter = 1:loop
        for b = 1:length(tx_sig)
            H = 1/sqrt(2)*randn(M,N)+1i*randn(M,N); % generation of MIMO channels
            noise = 1/sqrt(2)*[randn(M,1) + 1i*randn(M,1)]; % generation AWGN noise
            n = noise*(sqrt(N0(a))); % normalized noise times normalized tx. power

            y = H*tx_sig(:,b) + n;
            
            %% Detection using ML
            for ant_comb = 1:2^b_GSM
                for idx_sym = 1:size(s,2)
                    g(ant_comb,idx_sym) = norm(y - H*ML_sym(:,ant_comb,idx_sym))^2;
                end
            end            
            [val_temp,idx_temp] = min(g);
            [res(b),idx_sym_ML] = min(val_temp);
            dec_ant_idx(b) = idx_temp(idx_sym_ML);            
            sym_ML(:,b) = idx_s(:,idx_sym_ML);            
        end

        % Calculate no. of symbol error for ML (from all MIMO channels)
        symb_error_ML = symerr(decimal_symb,sym_ML);
        ant_error_ML = symerr(ant_idx,dec_ant_idx');
        SER_ML0(iter) = symb_error_ML + ant_error_ML;
    end

    % Calculate the average of symbol error ML (over all MIMO channels)
    mean_SER_ML = mean(SER_ML0);
    if mean_SER_ML < 1 % used to prevent symbol error < 1 (typically happens when simulate substantial no. of bits)
        mean_SER_ML = 0;
    end
    tot_SER_ML(a) = mean_SER_ML; % the average symbol error at snr(a)
end

SER_GSM_ML = tot_SER_ML./(prod(size(decimal_symb)) + prod(size(ant_idx))); % SER computation