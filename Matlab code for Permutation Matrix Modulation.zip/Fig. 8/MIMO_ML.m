% This function was developed to help our readers understand the novel
% index modulation system proposed in:
%
% Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho,
% "Permutation Matrix Modulation", IEEE Transactions on Wireless
% Communications, To appear.
% 
% The article can be downloaded at: https://arxiv.org/abs/2112.13630v3
% (to be published in IEEE Transactions on Wireless
% Communications)
%
% This code is the 1st version (Last edited: 28.12.2022)
%
% Please cite our paper as mentioned above if this code is used in any way,
% so that the readers will not be accused for plagiarism.
% 
% Enjoy our code :)

function[SER_MIMO_ML] = MIMO_ML(k_main,loop_main,snr_main,N_mimo,Q_mimo,M_mimo)

%% Input parameters
k = k_main; % for total no. of generated bits
loop = loop_main; % no. of iteration
snr = snr_main; % SNR values
N = N_mimo; % number of transmit antennas
Q = Q_mimo; % modulation level
M = M_mimo; % number of receive antenna

all_syms = qammod((0:Q-1),Q);
Eac = (mean(all_syms .* conj(all_syms)));
N0 = (Eac)*10.^(-snr/10); % noise variance
marray = log2(Q); % no. of bit per constellation symbol
num_of_bits = marray*10^k; % total no. of generated bits

%% Mapping Signal
for ante = 1:N
    bit_sym(ante,:) = randi([0 1],1,num_of_bits); % generation of bits
    bit_block_sym = reshape(bit_sym(ante,:),marray,num_of_bits/marray); % conversion bits to blocks
    decimal_symb(ante,:) = bi2de(bit_block_sym(1:marray,:).','left-msb')'; % decimal for constellation symbol
    x_mimo(ante,:) = (1/N)*qammod(decimal_symb(ante,:),Q); % symbol modulation
end

% Generation of all possible symbols for ML detection
for i = 1:N
    pl = (Q^N/(Q^i));
    for ii = 1:Q
        for iii = (ii-1)*pl+1:ii*pl
            s(i,iii) = ii;
        end
    end
    while s(i,Q^N) == 0
        s(i,:) = repmat(s(i,1:Q*pl),1,Q^N/(Q*pl));
    end
end
idx_s = s-1;
vec_s = (1/N)*qammod(idx_s,Q);

%% SER calculation
for i = 1:length(snr)
    disp(['MIMO P = ',num2str(snr(i)),' dB'])
    for iter = 1:loop
        for ii = 1:length(x_mimo)            
            H = 1/sqrt(2)*randn(M,N)+1i*randn(M,N); % generation of MIMO channels
            noise = 1/sqrt(2)*[randn(M,1) + 1i*randn(M,1)]; % generation AWGN noise
            n = noise*(sqrt(N0(i)));  % normalized noise times normalized tx. power
            
            y = H*x_mimo(:,ii) + n; % receive signal
            
            %% Detection using ML
            for idx_sym = 1:length(vec_s)
                g(idx_sym) = norm(y - H*vec_s(:,idx_sym))^2;
            end
            [val_temp,idx_temp] = min(g);            
            sym_ML(:,ii) = idx_s(:,idx_temp);
        end

        % Calculate no. of symbol error for ML (from all MIMO channels)
        SER_ML0(iter) = symerr(decimal_symb,sym_ML);        
    end

    % Calculate the average of symbol error ML (over all MIMO channels)
    mean_SER_ML = mean(SER_ML0);
    if mean_SER_ML < 1 % used to prevent symbol error < 1 (typically happens when simulate substantial no. of bits)
        mean_SER_ML = 0;
    end
    tot_SER_ML(i) = mean_SER_ML; % the average symbol error at snr(i)
end

SER_MIMO_ML = tot_SER_ML./(prod(size(decimal_symb))); % SER computation