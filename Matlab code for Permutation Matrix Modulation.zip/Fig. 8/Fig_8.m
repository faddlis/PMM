% This function was developed to help our readers understand the novel
% index modulation system proposed in:
%
% Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho,
% "Permutation Matrix Modulation", IEEE Transactions on Wireless
% Communications.
% 
% The article can be downloaded at: https://ieeexplore.ieee.org/abstract/document/10002396
%
% This code is the 1st version (Last edited: 28.03.2023)
%
% Please cite our paper as mentioned above if this code is used in any way,
% so that the readers will not be accused for plagiarism.
% 
% Enjoy our code :)

clc; clear all;

% General parameters
k_main = 2; % total no. of generated symbols
loop_main = 1; % no. of iterations
snr_main = 0:5:40; % the SNR values

% Input parameters for PMM
N_pmm = 5;
M_pmm = 4;
Q_pmm = 4;

% Input parameters for GSM
N_gsm = 6;
M_gsm = 4;
Q_gsm = 16;

% Input parameters for MIMO
N_mimo = 4;
M_mimo = 4;
Q_mimo = 16;

% Input parameters for SM
N_sm = 256;
M_sm = 4;
Q_sm = 256;
k_sm = 3; % exception for k_sm must be >= 3 since N = 256, otherwise error is resulted in


SER_PMM_ML = PMM_ML(k_main,loop_main,snr_main,N_pmm,Q_pmm,M_pmm);
SER_GSM_ML = GSM_ML(k_main,loop_main,snr_main,N_gsm,Q_gsm,M_gsm);
SER_MIMO_ML = MIMO_ML(k_main,loop_main,snr_main,N_mimo,Q_mimo,M_mimo);
SER_SM_ML = SM_ML(k_sm,loop_main,snr_main,N_sm,Q_sm,M_sm);

figure(1),
semilogy(snr_main,SER_PMM_ML,'-','LineWidth',2,'DisplayName',strcat('PMM (',num2str(N_pmm),'\times',num2str(M_pmm),', ',num2str(Q_pmm),'PSK)')), grid on, hold on
semilogy(snr_main,SER_GSM_ML,':','LineWidth',2,'DisplayName',strcat('GSM (',num2str(N_gsm),'\times',num2str(M_gsm),', ',num2str(Q_gsm),'QAM)'))
semilogy(snr_main,SER_MIMO_ML,'--','LineWidth',2,'DisplayName',strcat('MIMO (',num2str(N_mimo),'\times',num2str(M_mimo),', ',num2str(Q_mimo),'QAM)'))
semilogy(snr_main,SER_SM_ML,'-.','LineWidth',2,'DisplayName',strcat('SM (',num2str(N_sm),'\times',num2str(M_sm),', ',num2str(Q_sm),'QAM)'))

xlabel('SNR (dB)')
ylabel('SER')
legend('show','Location','southwest')