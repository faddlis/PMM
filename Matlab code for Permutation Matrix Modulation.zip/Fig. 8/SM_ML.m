% This function was developed to help our readers understand the novel
% index modulation system proposed in:
%
% Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho,
% "Permutation Matrix Modulation", IEEE Transactions on Wireless
% Communications, To appear.
% 
% The article can be downloaded at: https://arxiv.org/abs/2112.13630v3
% (to be published in IEEE Transactions on Wireless
% Communications)
%
% This code is the 1st version (Last edited: 28.12.2022)
%
% Please cite our paper as mentioned above if this code is used in any way,
% so that the readers will not be accused for plagiarism.
% 
% Enjoy our code :)

function[SER_SM_ML] = SM_ML(k_sm,loop_main,snr_main,N_sm,Q_sm,M_sm)

%% Input parameters
k = k_sm; % for total no. of generated bits
loop = loop_main; % no. of iteration
snr = snr_main; % SNR values
N = N_sm; % number of transmit antennas
Q = Q_sm; % modulation level
M = M_sm; % number of receive antenna

marray = log2(Q); % no. of bit per constellation symbol
b_SM = log2(N); % no. of modulated bits to a cov. matrix
Nbits = (marray+b_SM)*10^k; % total no. of generated bits
bit_input = randi([0 1],1,Nbits); % generation of bits
all_sym = qammod((0:Q-1),Q);
Eac = (mean(all_sym .* conj(all_sym)));
No = (Eac)*10.^(-snr/10); % noise variance

x = reshape(bit_input,marray+b_SM,[]); % converting generated bits to blocks
ante = bi2de([x(1:b_SM,:)].' , 'left-msb') + 1; % antenna selection

decimal = bi2de(x(b_SM+1:end,:).','left-msb'); % converting block of bits to decimal number
mod = qammod(decimal,Q); % symbol modulation

for i = 1 : length(mod)
    mod_T( ante(i) , i) = mod(i); % symbol positioning -> transmit signal
end

%% SER calculation
for a = 1:length(snr)
    disp(['SM P = ',num2str(snr(a)),' dB'])
    for iter = 1:loop
        for aaa = 1:length(mod_T)
            H = 1/sqrt(2)*randn(M,N)+1i*randn(M,N); % generation of MIMO channels
            noise = 1/sqrt(2)*[randn(M,1) + 1i*randn(M,1)]; % generation AWGN noise          
            n = noise*(sqrt(No(a))); % normalized noise times normalized tx. power

            y = H*mod_T(:,aaa) + n; % receive signal
            yy = kron(y,ones(1,Q)); % duplication of receive signal for detection

            %% Detection using ML
            ML = zeros(N,Q);
            for k = 1:N
                ML(k,:) = sum(abs(yy - H(:,k)*all_sym).^2);
            end            
            [temp1 temp2] = min(ML);
            [~, sym_small] = min(temp1);    % position of symbol that gives smallest value
            sym_num(aaa) = temp2(sym_small);     % finding the antenna number
            symb = all_sym(sym_small); % detection of constellation symbol
            demod(aaa) = qamdemod(symb,Q); % constellation symbol in decimal
        end
        
     % Calculate no. of symbol error for ML (from all MIMO channels)
    error_ant = symerr(ante',sym_num);
    error_symb = symerr(decimal',demod);
    SER_ML0(iter) = error_ant + error_symb;
    end
    
    % Calculate the average of symbol error ML (over all MIMO channels)
    mean_ser = mean(SER_ML0);
    if mean_ser < 1 % used to prevent symbol error < 1 (typically happens when simulate substantial no. of bits)
        mean_ser = 0;
    end
    tot_SER_ML(1,a) = mean_ser;
end

SER_SM_ML = tot_SER_ML/(length(ante) + length(decimal)); % SER computation