% This function was developed to help our readers understand the novel
% index modulation system proposed in:
%
% Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho,
% "Permutation Matrix Modulation", IEEE Transactions on Wireless
% Communications.
% 
% The article can be downloaded at: https://ieeexplore.ieee.org/abstract/document/10002396
%
% This code is the 1st version (Last edited: 28.03.2023)
%
% Please cite our paper as mentioned above if this code is used in any way,
% so that the readers will not be accused for plagiarism.
% 
% Enjoy our code :)

%% Complexity ratio for different number of Tx. antennas
clc; clear all;
N = 2:1:8; % no. of transmit antenna
M = 4; % no. of receive antenna
Q = 4; % modulation level
b = floor(log2(factorial(N))); % no. of modulated bits to a permutation matrix (PM)
r = 2.^b; % no. of covariance matrices

for i = 1:length(N)
    C_ML(i) = r(i)*(Q^N(i))*(N(i)^2 + N(i) + (2*N(i)-1)*M + 3*M-1); % equation (57) -> fixed M & Q
    C_ZF(i) = 4*N(i)^3 + 2*((N(i)^2)*M + (M-1)*N(i) + r(i)*(4*M-1)) + 2*N(i)*Q; % equation (58) -> fixed M & Q
end
subplot 211;
plot(N,C_ML./C_ZF,':o','LineWidth',1,'DisplayName','N'),grid on, hold on
xlabel('N')
ylabel('Comp. ratio')


%% Complexity ratio for different contellation size
clc; clear all;
N = 4; % no. of transmit antenna
M = 4; % no. of receive antenna
Q = [2 4 8 16]; % modulation level
b = floor(log2(factorial(N))); % no. of modulated bits to a permutation matrix (PM)
r = 2.^b; % no. of covariance matrices

for i = 1:length(Q)
    C_ML_Q(i) = r*(Q(i)^N)*(N^2 + N + (2*N-1)*M + 3*M-1); % equation (57) -> fixed N & M
    C_ZF_Q(i) = 4*N^3 + 2*((N^2)*M + (M-1)*N + r*(4*M-1)) + 2*N*Q(i); % equation (58) -> fixed N & M
end

subplot 212;
plot(Q,C_ML_Q./C_ZF_Q,':x','LineWidth',1,'DisplayName','Q'),grid on, hold on
xlabel('Q')
ylabel('Comp. ratio')