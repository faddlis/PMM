Matlab code for Permutation Matrix Modulation

We mean to help our readers to understand our proposed system in the article: Rahmat Faddli Siregar, 
Nandana Rajatheva, and Matti Latva-Aho, "Permutation Matrix Modulation", IEEE Transactions on Wireless Communications, 
that can be downloaded at: https://ieeexplore.ieee.org/abstract/document/10002396.

Please cite our paper as mentioned above if this code is used in any way.

Enjoy our code :)