Matlab code for Permutation Matrix Modulation

We mean to help our readers to understand our proposed system in the article:
Rahmat Faddli Siregar, Nandana Rajatheva, and Matti Latva-Aho, "Permutation Matrix Modulation", IEEE Transactions on Wireless Communications (to appear),
that can be downloaded at: https://arxiv.org/abs/2112.13630v3 (to be published in IEEE Transactions on Wireless Communications).

Please cite our paper as mentioned above if this code is used in any way, so that the readers will not be accused for plagiarism.

Enjoy our code :)